#ifndef  __INCLUDES_H__
#define  __INCLUDES_H__

#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os.h"
#include "FreeRTOS.h"
#include "task.h"


#include "GetAnalyse.h"
#include "signal.h"
#include "Sim80x.h"
#include <stdio.h>
#include <stdlib.h>
#include "exparameter.h"
#include "ReportStatePacket.h"
#include "encode.h"
#include "iwdg.h"
#include "gas.h"
#include "MB85RS16A.h"

#include "cJSON.h"
#endif
