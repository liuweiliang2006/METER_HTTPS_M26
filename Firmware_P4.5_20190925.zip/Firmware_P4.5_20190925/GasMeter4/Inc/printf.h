/**
  ******************************************************************************
  * File Name          : 
  * Description        : 
  ******************************************************************************
*/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __printf_H
#define __printf_H
#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"
#include "main.h"

//#define 
void myPrintf(char *str);



#ifdef __cplusplus
}
#endif
#endif /*__printf_H */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
